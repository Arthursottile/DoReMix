package br.edu.utfpr.arthursottile.doremix;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;
import java.util.List;

public class MusicaActivity extends AppCompatActivity {

    private ListView listViewMusica;

    private List<Musica> listaMusica;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_musica);

        listViewMusica = findViewById(R.id.listViewMusica);

        popularListaMusica();
    }

    private void popularListaMusica() {

    String[]    titulo   = getResources().getStringArray(R.array.musica_Titulo);
    String[]    autor    = getResources().getStringArray(R.array.musica_Autor);
    String[]    tom      = getResources().getStringArray(R.array.musica_Tom);
    int[]       duracoes = getResources().getIntArray(R.array.musica_Duracao);

    listaMusica = new ArrayList<>();



        for(int cont = 0; cont < titulo.length; cont++){

            Musica musica = new Musica(
                    titulo[cont],
                    autor[cont],
                    tom[cont],
                    duracoes[cont]
            );
            listaMusica.add(musica);
        }

        ArrayAdapter<Musica> adapter = new ArrayAdapter<>(this,
                                                          android.R.layout.simple_list_item_1,
                                                          listaMusica);

        listViewMusica.setAdapter(adapter);
    }
}