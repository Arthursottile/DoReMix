package br.edu.utfpr.arthursottile.doremix;

public class Musica {

    private String titulo;

    private String autor;

    private int duracao;

    private String tom;

    public Musica(String titulo, String autor, String tom,int duracao) {
        this.titulo     = titulo;
        this.autor      = autor;
        this.tom        = tom;
        this.duracao    = duracao;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getDuracao() {
        return duracao;
    }

    public void setDuracao(int duracao) {
        this.duracao = duracao;
    }

    public String getTom() {
        return tom;
    }

    public void setTom(String tom) {
        this.tom = tom;
    }

    @Override
    public String toString() {

        int minutos = duracao / 60;
        int segundos = duracao % 60;
        String duracaoFormatada = String.format("%d:%02d", minutos, segundos);

        return titulo               + '\n' +
               autor                + '\n' +
               duracaoFormatada     + '\n' +
               "Tom: " + tom;
    }
}
